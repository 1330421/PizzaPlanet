# PizzaPlanet - TP3 Volet A
Projet qui gère les commandes de pizzerias

A Louis-Philippe Brunet 1555921
B Jordan Côté 1657817
C Kevin St-Pierre